import { a as addHmrIntoView } from "./_virtual_reload-on-update-in-view.js";
addHmrIntoView("pages/content");
const animation = document.createElement("style");
animation.innerHTML = `
@-webkit-keyframes fadeInRight {
  0% {
     opacity: 0;
     -webkit-transform: translateX(20px);
  }
  100% {
     opacity: 1;
     -webkit-transform: translateX(0);
  }
}

@keyframes fadeInRight {
  0% {
     opacity: 0;
     transform: translateX(20px);
  }
  100% {
     opacity: 1;
     transform: translateX(0);
  }
}

.fadeInRight {
  -webkit-animation-name: fadeInRight;
  animation-name: fadeInRight;
}

@-webkit-keyframes fadeOutRight {
  100% {
     opacity: 0;
     -webkit-transform: translateX(20px);
  }
  0% {
     opacity: 1;
     -webkit-transform: translateX(0);
  }
}

@keyframes fadeOutRight {
  100% {
     opacity: 0;
     transform: translateX(20px);
  }
  0% {
     opacity: 1;
     transform: translateX(0);
  }
}

.fadeOutRight {
  -webkit-animation-name: fadeOutRight;
  animation-name: fadeOutRight;
}
`;
document.head.append(animation);
const EVENT_OPTIONS = {
  bubbles: true,
  cancelable: false,
  composed: true
};
const EVENTS = {
  BLUR: new Event("blur", EVENT_OPTIONS),
  CHANGE: new Event("change", EVENT_OPTIONS),
  INPUT: new Event("input", EVENT_OPTIONS)
};
const iframeURL = chrome.runtime.getURL("src/pages/main/index.html");
const rootId = "salu-mail-email-autofill-root";
let inputFocused = false;
let inputElement = null;
const removeRoot = () => {
  const root = document.getElementById(rootId);
  if (root) {
    inputElement = null;
    root.classList.add("fadeOutRight");
    setTimeout(() => {
      root.remove();
    }, 250);
  }
};
const checkIfSaluMailRoot = (element) => {
  const root = document.getElementById(rootId);
  return root && root.contains(element);
};
function checkIfEmailInput(element) {
  var _a, _b, _c, _d, _e, _f;
  if (element.tagName === "INPUT") {
    const input = element;
    const isEmailInput = ((_a = input.type) == null ? void 0 : _a.toLowerCase()) === "email";
    const isIdEmail = ((_b = input.id) == null ? void 0 : _b.toLowerCase()) === "email";
    const isNameEmail = ((_c = input.name) == null ? void 0 : _c.toLowerCase()) === "email";
    const isClassEmail = (_d = input.className.toLowerCase()) == null ? void 0 : _d.includes("email");
    const isAriaLabelEmail = ((_e = input.getAttribute("aria-label")) == null ? void 0 : _e.toLowerCase()) === "email";
    const hasEmailLabel = (_f = document.querySelector(`label[for="${input.id}"]`)) == null ? void 0 : _f.textContent.toLowerCase().includes("email");
    return isEmailInput || isIdEmail || isNameEmail || isClassEmail || isAriaLabelEmail || hasEmailLabel;
  } else {
    return false;
  }
}
const createRoot = ({
  height,
  width,
  left,
  top
}) => {
  const oldRoot = document.getElementById(rootId);
  if (oldRoot) {
    oldRoot.remove();
  }
  const siteRootDomain = document.domain.split(".").reverse().splice(0, 2).reverse().join(".");
  const root = document.createElement("iframe");
  root.id = rootId;
  root.style.position = "absolute";
  root.style.height = `${height}px`;
  root.style.width = `${width}px`;
  root.style.left = `${left}px`;
  root.style.top = `${top}px`;
  root.style.borderRadius = "10px";
  root.style.zIndex = "99999999999999999";
  root.style.boxShadow = "rgba(149, 157, 165, 0.2) 0px 8px 24px";
  root.style.border = "none";
  root.classList.add("fadeInRight");
  root.style.animationFillMode = "both";
  root.style.animationDuration = "0.25s";
  root.style.animationTimingFunction = "ease";
  root.src = `${iframeURL}#${siteRootDomain}`;
  document.body.append(root);
};
window.addEventListener("resize", () => {
  removeRoot();
});
document.addEventListener("focusout", () => inputFocused = false);
document.addEventListener("focusin", (event) => {
  const target = event.target;
  if (checkIfEmailInput(target)) {
    const containerHeight = 300;
    const containerWidth = 400;
    inputFocused = true;
    const input = target;
    inputElement = input;
    const {
      height,
      width,
      left,
      top
    } = input.getBoundingClientRect();
    createRoot({
      height: containerHeight,
      width: containerWidth,
      left: left + width + 20,
      top: top - containerHeight / 2 + height / 2
    });
  }
});
document.addEventListener("click", (event) => {
  const target = event.target;
  if (!checkIfEmailInput(target) && !checkIfSaluMailRoot(target) && !inputFocused) {
    removeRoot();
  }
  if (checkIfEmailInput(target)) {
    const root = document.getElementById(rootId);
    if (!root) {
      const containerHeight = 300;
      const containerWidth = 400;
      inputFocused = true;
      const input = target;
      inputElement = input;
      const {
        height,
        width,
        left,
        top
      } = input.getBoundingClientRect();
      createRoot({
        height: containerHeight,
        width: containerWidth,
        left: left + width + 20,
        top: top - containerHeight / 2 + height / 2
      });
    }
  }
});
window.onmessage = (event) => {
  if (typeof event === "object" && "data" in event && typeof event.data === "object") {
    const data = event.data;
    if ("type" in data && typeof data.type === "string") {
      if (data.type === "autofill" && "email" in data && typeof data.email === "string" && inputElement) {
        inputElement.value = data.email;
        inputElement.dispatchEvent(EVENTS.INPUT);
        removeRoot();
      }
      if (data.type === "open" && "url" in data && typeof data.url === "string") {
        window.open(data.url, "_blank");
      }
    }
  }
};
