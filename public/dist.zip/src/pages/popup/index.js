import { j as jsx, b as jsxs, d as createRoot } from "../../../assets/js/jsx-runtime.js";
import { a as addHmrIntoView } from "../../../assets/js/_virtual_reload-on-update-in-view.js";
const index = "";
const logo = "/assets/svg/imgLogo.chunk.svg";
const Popup$1 = "";
const Popup = () => {
  return /* @__PURE__ */ jsx("div", {
    className: "App",
    children: /* @__PURE__ */ jsxs("header", {
      className: "App-header",
      children: [/* @__PURE__ */ jsx("img", {
        src: logo,
        className: "App-logo",
        alt: "logo"
      }), /* @__PURE__ */ jsxs("p", {
        children: ["Edit ", /* @__PURE__ */ jsx("code", {
          children: "src/pages/popup/Popup.tsx"
        }), " and save to reload."]
      }), /* @__PURE__ */ jsx("a", {
        className: "App-link",
        href: "https://reactjs.org",
        target: "_blank",
        rel: "noopener noreferrer",
        children: "Learn React!"
      })]
    })
  });
};
addHmrIntoView("pages/popup");
function init() {
  const appContainer = document.querySelector("#app-container");
  if (!appContainer) {
    throw new Error("Can not find #app-container");
  }
  const root = createRoot(appContainer);
  root.render(/* @__PURE__ */ jsx(Popup, {}));
}
init();
