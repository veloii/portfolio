import{t as I}from"./index.5330192f.js";import"./_commonjsHelpers.d3f49fb8.js";const g=document.createElement("style");g.innerHTML=`
@-webkit-keyframes fadeInRight {
  0% {
     opacity: 0;
     -webkit-transform: translateX(20px);
  }
  100% {
     opacity: 1;
     -webkit-transform: translateX(0);
  }
}

@keyframes fadeInRight {
  0% {
     opacity: 0;
     transform: translateX(20px);
  }
  100% {
     opacity: 1;
     transform: translateX(0);
  }
}

.fadeInRight {
  -webkit-animation-name: fadeInRight;
  animation-name: fadeInRight;
}

@-webkit-keyframes fadeOutRight {
  100% {
     opacity: 0;
     -webkit-transform: translateX(20px);
  }
  0% {
     opacity: 1;
     -webkit-transform: translateX(0);
  }
}

@keyframes fadeOutRight {
  100% {
     opacity: 0;
     transform: translateX(20px);
  }
  0% {
     opacity: 1;
     transform: translateX(0);
  }
}

.fadeOutRight {
  -webkit-animation-name: fadeOutRight;
  animation-name: fadeOutRight;
}
`;document.head.append(g);const f={bubbles:!0,cancelable:!1,composed:!0},L={BLUR:new Event("blur",f),CHANGE:new Event("change",f),INPUT:new Event("input",f)},k=chrome.runtime.getURL("src/pages/main/index.html"),d="salu-mail-email-autofill-root";let m=!1,l=null;const h=()=>{const n=document.getElementById(d);n&&(l=null,n.classList.add("fadeOutRight"),setTimeout(()=>{n.remove()},250))},x=n=>{const t=document.getElementById(d);return t&&t.contains(n)};function p(n){var t,s,r,o,i,e;if(n.tagName==="INPUT"){const a=n,c=((t=a.type)==null?void 0:t.toLowerCase())==="email",u=((s=a.id)==null?void 0:s.toLowerCase())==="email",w=((r=a.name)==null?void 0:r.toLowerCase())==="email",b=(o=a.className.toLowerCase())==null?void 0:o.includes("email"),E=((i=a.getAttribute("aria-label"))==null?void 0:i.toLowerCase())==="email",R=(e=document.querySelector(`label[for="${a.id}"]`))==null?void 0:e.textContent.toLowerCase().includes("email");return c||u||w||b||E||R}else return!1}const y=({height:n,width:t,left:s,top:r})=>{const o=document.getElementById(d);o&&o.remove();const i=I.getDomain(window.location.href),e=document.createElement("iframe");e.id=d,e.style.position="absolute",e.style.height=`${n}px`,e.style.width=`${t}px`,e.style.left=`${s}px`,e.style.top=`${r}px`,e.style.borderRadius="10px",e.style.zIndex="99999999999999999",e.style.boxShadow="rgba(149, 157, 165, 0.2) 0px 8px 24px",e.style.border="none",e.classList.add("fadeInRight"),e.style.animationFillMode="both",e.style.animationDuration="0.25s",e.style.animationTimingFunction="ease",e.src=`${k}#${i}`,document.body.append(e)};window.addEventListener("resize",()=>{h()});document.addEventListener("focusout",()=>m=!1);document.addEventListener("focusin",n=>{const t=n.target;if(p(t)){m=!0;const o=t;l=o;const{height:i,width:e,left:a,top:c}=o.getBoundingClientRect();y({height:300,width:400,left:a+e+20,top:c-300/2+i/2})}});document.addEventListener("click",n=>{const t=n.target;if(!p(t)&&!x(t)&&!m&&h(),p(t)&&!document.getElementById(d)){m=!0;const i=t;l=i;const{height:e,width:a,left:c,top:u}=i.getBoundingClientRect();y({height:300,width:400,left:c+a+20,top:u-300/2+e/2})}});window.onmessage=n=>{if(typeof n=="object"&&"data"in n&&typeof n.data=="object"){const t=n.data;"type"in t&&typeof t.type=="string"&&(t.type==="autofill"&&"email"in t&&typeof t.email=="string"&&l&&(l.value=t.email,l.dispatchEvent(L.INPUT),h()),t.type==="open"&&"url"in t&&typeof t.url=="string"&&window.open(t.url,"_blank"))}};
